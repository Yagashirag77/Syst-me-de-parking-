const db = require("../models/db");
const QRCode = require("qrcode");
const moment = require("moment");

exports.generateQRCode = async (req, res) => {
  const { utilisateur_id } = req.body;
  const code = `QR-${utilisateur_id}-${Date.now()}`;
  const date_creation = moment().format("YYYY-MM-DD HH:mm:ss");

  try {
    await QRCode.toDataURL(code); // Optionnel, juste pour valider
    db.query("INSERT INTO qrcodes (utilisateur_id, code, date_creation) VALUES (?, ?, ?)",
      [utilisateur_id, code, date_creation], (err, result) => {
        if (err) return res.status(500).json({ error: err });
        res.json({ code_qr: code });
      });
  } catch (e) {
    res.status(500).json({ error: "Erreur QR code" });
  }
};

exports.entreeParking = (req, res) => {
  const { code_qr } = req.body;
  const now = moment().format("YYYY-MM-DD HH:mm:ss");

  db.query("INSERT INTO entree_sortie (code_qr, date_entree) VALUES (?, ?)", [code_qr, now],
    (err) => {
      if (err) return res.status(500).json({ error: err });
      res.json({ message: "Entrée enregistrée", date_entree: now });
    }
  );
};

exports.sortieParking = (req, res) => {
  const { code_qr } = req.body;
  const now = moment().format("YYYY-MM-DD HH:mm:ss");

  db.query("SELECT date_entree FROM entree_sortie WHERE code_qr = ? AND date_sortie IS NULL", [code_qr],
    (err, results) => {
      if (err || results.length === 0) return res.status(500).json({ error: "Code invalide ou déjà sorti" });

      const dateEntree = moment(results[0].date_entree);
      const duree = moment(now).diff(dateEntree, 'minutes');
      const tarif = (duree * 0.5).toFixed(2); // 0.5 MAD/minute

      db.query("UPDATE entree_sortie SET date_sortie = ?, tarif = ? WHERE code_qr = ?",
        [now, tarif, code_qr],
        (err2) => {
          if (err2) return res.status(500).json({ error: err2 });
          res.json({ message: "Sortie enregistrée", duree: `${duree} min`, tarif: `${tarif} MAD` });
        });
    }
  );
};
