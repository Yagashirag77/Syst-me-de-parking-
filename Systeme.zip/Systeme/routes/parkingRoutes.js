const express = require("express");
const router = express.Router();
const controller = require("../controllers/parkingController");

router.post("/generate-qrcode", controller.generateQRCode);
router.post("/entree", controller.entreeParking);
router.post("/sortie", controller.sortieParking);

module.exports = router;
