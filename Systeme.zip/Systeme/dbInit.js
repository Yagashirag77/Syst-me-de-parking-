const db = require('./models/db');

const createUtilisateurs = `
  CREATE TABLE IF NOT EXISTS utilisateurs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nom VARCHAR(100),
    email VARCHAR(100),
    mot_de_passe VARCHAR(100)
  );
`;

const createQRCodes = `
  CREATE TABLE IF NOT EXISTS qrcodes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    utilisateur_id INT,
    code VARCHAR(255),
    actif BOOLEAN DEFAULT TRUE,
    date_creation DATETIME,
    FOREIGN KEY (utilisateur_id) REFERENCES utilisateurs(id)
  );
`;

const createEntreeSortie = `
  CREATE TABLE IF NOT EXISTS entree_sortie (
    id INT AUTO_INCREMENT PRIMARY KEY,
    code_qr VARCHAR(255),
    date_entree DATETIME,
    date_sortie DATETIME,
    tarif DOUBLE
  );
`;

db.query(createUtilisateurs, (err) => {
  if (err) return console.error(" Erreur table utilisateurs :", err);
  console.log("✅ Table utilisateurs créée.");

  db.query(createQRCodes, (err) => {
    if (err) return console.error(" Erreur table qrcodes :", err);
    console.log("✅ Table qrcodes créée.");

    db.query(createEntreeSortie, (err) => {
      if (err) return console.error(" Erreur table entree_sortie :", err);
      console.log("✅ Table entree_sortie créée.");

      db.end();
    });
  });
});
