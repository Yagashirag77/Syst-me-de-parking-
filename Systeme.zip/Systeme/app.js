const express = require("express");
const bodyParser = require("body-parser");
const dotenv = require("dotenv");
dotenv.config();

const app = express();
app.use(bodyParser.json());

// Connexion à la base de données MySQL (via models/db.js)
require("./models/db");

// Routes
const parkingRoutes = require("./routes/parkingRoutes");
app.use("/api", parkingRoutes);

// Démarrage du serveur
app.listen(process.env.PORT, () => {
  console.log(`🚀 Serveur démarré sur le port ${process.env.PORT}`);
});
